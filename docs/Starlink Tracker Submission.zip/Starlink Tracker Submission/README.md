For Either Professor:
We have added you to our repo so you can access our code there. Please replace the contents of the env.json
inside the back-end folder in the working directory with the following:

{
    "host": "localhost",
    "base_api_url": "https://www.n2yo.com/rest/v1/satellite/",
    "api_key": "R8SFPS-EP92UH-F829BU-4IQA",
    "user": "postgres",
    "database": "starlinktracker",
    "password": "ADD_YOUR_OWN_PASSWORD",
    "port": 5432
}

Instructions on how to run the app are in the README in the repository.